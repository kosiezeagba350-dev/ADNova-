# North America foundation update

## Added
- Global brand metadata and US-first rollout documentation.
- `workspace_market_profiles` table for country, currency, time zone, state/province, business/workspace type, industry and website.
- Public `GET /market/config` endpoint.
- Authenticated `GET` and `PUT /workspace/market-profile` endpoints.
- US/CA/NG currency-pair validation.
- Dashboard Market Profile screen.
- North American architecture, agency tenant-isolation design, trust/security launch gates and phased rollout document.
- Backend smoke tests for market configuration and profile persistence.

## Not activated by this update
- Live subscription checkout or tax calculation.
- Meta/Google advertising account OAuth or campaign execution.
- Agency multi-client delegation and client invitations.
- SOC 2 / ISO certification or independent security audit.
- Country-specific legal compliance certification.

The update is an implementation foundation, not a claim that the platform is ready for paid public launch.
