from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

def test_health():
    r=client.get("/health")
    assert r.status_code==200
    assert r.json()["status"]=="ok"

def test_registration_and_dashboard():
    import uuid
    email=f"{uuid.uuid4().hex}@example.test"
    r=client.post("/auth/register",json={"full_name":"Test User","email":email,"password":"correct-horse-battery","workspace_name":"Test"})
    assert r.status_code==200
    token=r.json()["access_token"]
    h={"Authorization":f"Bearer {token}"}
    assert client.get("/dashboard",headers=h).status_code==200
    assert client.post("/leads",headers=h,json={"name":"Lead One","company":"Example"}).status_code==200
    assert len(client.get("/leads",headers=h).json())==1


def test_market_config_and_workspace_profile():
    import uuid
    cfg=client.get("/market/config")
    assert cfg.status_code==200
    assert cfg.json()["launch_market"]=="US"
    email=f"{uuid.uuid4().hex}@example.test"
    r=client.post("/auth/register",json={"full_name":"Market Tester","email":email,"password":"correct-horse-battery","workspace_name":"US Test Workspace"})
    assert r.status_code==200
    h={"Authorization":f"Bearer {r.json()['access_token']}"}
    profile=client.get("/workspace/market-profile",headers=h)
    assert profile.status_code==200
    assert profile.json()["country_code"]=="US"
    updated=client.put("/workspace/market-profile",headers=h,json={"country_code":"US","currency_code":"USD","timezone":"America/Chicago","state_or_province":"Texas","business_type":"small_business","workspace_type":"business","industry":"home_services","website":"https://example.com"})
    assert updated.status_code==200
    mismatch=client.put("/workspace/market-profile",headers=h,json={"country_code":"US","currency_code":"CAD","timezone":"America/New_York"})
    assert mismatch.status_code==422
