import os, uuid, json
from datetime import datetime, timedelta, timezone
from typing import Optional
from fastapi import FastAPI, Depends, HTTPException, status, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import create_engine, String, Integer, Float, Boolean, DateTime, Text, ForeignKey, select, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker, Session
from jose import jwt, JWTError
from passlib.context import CryptContext

APP_ENV = os.getenv("APP_ENV", "development")
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./adnova.db")
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql+psycopg://", 1)
elif DATABASE_URL.startswith("postgresql://"):
    DATABASE_URL = DATABASE_URL.replace("postgresql://", "postgresql+psycopg://", 1)
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
JWT_SECRET = os.getenv("JWT_SECRET", "dev-only-change-this-secret")
TOKEN_MINUTES = int(os.getenv("ACCESS_TOKEN_MINUTES", "10080"))
pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2 = OAuth2PasswordBearer(tokenUrl="/auth/login")

class Base(DeclarativeBase): pass

class Workspace(Base):
    __tablename__ = "workspaces"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name: Mapped[str] = mapped_column(String(160), default="My Workspace")
    plan: Mapped[str] = mapped_column(String(40), default="trial")
    trial_ends_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)+timedelta(days=14))
    ai_budget_usd: Mapped[float] = mapped_column(Float, default=float(os.getenv("AI_MONTHLY_BUDGET_USD","25")))
    ai_spend_usd: Mapped[float] = mapped_column(Float, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class User(Base):
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(160))
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(30), default="owner")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class Lead(Base):
    __tablename__ = "leads"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True)
    name: Mapped[str] = mapped_column(String(180))
    company: Mapped[str] = mapped_column(String(180), default="")
    email: Mapped[str] = mapped_column(String(255), default="")
    source: Mapped[str] = mapped_column(String(80), default="manual")
    status: Mapped[str] = mapped_column(String(40), default="new")
    score: Mapped[int] = mapped_column(Integer, default=0)
    notes: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class Activity(Base):
    __tablename__ = "activities"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True)
    lead_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    kind: Mapped[str] = mapped_column(String(60))
    description: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class ResearchItem(Base):
    __tablename__ = "research_items"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True)
    title: Mapped[str] = mapped_column(String(220))
    company: Mapped[str] = mapped_column(String(180), default="")
    url: Mapped[str] = mapped_column(String(500), default="")
    summary: Mapped[str] = mapped_column(Text, default="")
    score: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(40), default="saved")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class ContentItem(Base):
    __tablename__ = "content_items"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True)
    title: Mapped[str] = mapped_column(String(220))
    channel: Mapped[str] = mapped_column(String(60), default="blog")
    body: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(40), default="draft")
    scheduled_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class Campaign(Base):
    __tablename__ = "campaigns"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True)
    name: Mapped[str] = mapped_column(String(180))
    channel: Mapped[str] = mapped_column(String(60), default="email")
    status: Mapped[str] = mapped_column(String(40), default="draft")
    audience: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class Approval(Base):
    __tablename__ = "approvals"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True)
    action_type: Mapped[str] = mapped_column(String(80))
    title: Mapped[str] = mapped_column(String(220))
    payload: Mapped[str] = mapped_column(Text, default="{}")
    status: Mapped[str] = mapped_column(String(40), default="pending")
    requested_by: Mapped[str] = mapped_column(String(36))
    decided_by: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    decided_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

class Subscription(Base):
    __tablename__ = "subscriptions"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), unique=True, index=True)
    provider: Mapped[str] = mapped_column(String(40), default="manual")
    provider_customer_id: Mapped[str] = mapped_column(String(180), default="")
    provider_subscription_id: Mapped[str] = mapped_column(String(180), default="")
    status: Mapped[str] = mapped_column(String(40), default="trialing")
    plan: Mapped[str] = mapped_column(String(40), default="starter")
    monthly_amount_usd: Mapped[float] = mapped_column(Float, default=0)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class WorkspaceMarketProfile(Base):
    __tablename__ = "workspace_market_profiles"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), unique=True, index=True)
    country_code: Mapped[str] = mapped_column(String(2), default="US")
    currency_code: Mapped[str] = mapped_column(String(3), default="USD")
    timezone: Mapped[str] = mapped_column(String(80), default="America/New_York")
    state_or_province: Mapped[str] = mapped_column(String(100), default="")
    business_type: Mapped[str] = mapped_column(String(60), default="small_business")
    workspace_type: Mapped[str] = mapped_column(String(30), default="business")
    industry: Mapped[str] = mapped_column(String(100), default="home_services")
    website: Mapped[str] = mapped_column(String(500), default="")
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class AuditEvent(Base):
    __tablename__ = "audit_events"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True)
    user_id: Mapped[str] = mapped_column(String(36))
    event: Mapped[str] = mapped_column(String(120))
    details: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

Base.metadata.create_all(engine)
app = FastAPI(title="AdNova Global API", version="1.1.0", description="Global multi-tenant growth operations platform; US-first market rollout")
app.add_middleware(CORSMiddleware, allow_origins=[x.strip() for x in os.getenv("FRONTEND_ORIGIN","http://localhost:3000").split(",")], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

def db():
    s=SessionLocal()
    try: yield s
    finally: s.close()

def token_for(user):
    return jwt.encode({"sub":user.id,"wid":user.workspace_id,"exp":datetime.now(timezone.utc)+timedelta(minutes=TOKEN_MINUTES)}, JWT_SECRET, algorithm="HS256")

def current_user(token: str=Depends(oauth2), s: Session=Depends(db)):
    try: data=jwt.decode(token, JWT_SECRET, algorithms=["HS256"]); uid=data["sub"]; wid=data["wid"]
    except (JWTError, KeyError): raise HTTPException(401,"Invalid or expired session")
    user=s.scalar(select(User).where(User.id==uid,User.workspace_id==wid))
    if not user: raise HTTPException(401,"User not found")
    return user

def audit(s, user, event, details=""):
    s.add(AuditEvent(workspace_id=user.workspace_id,user_id=user.id,event=event,details=details))

class RegisterIn(BaseModel):
    full_name: str = Field(min_length=2,max_length=160)
    email: EmailStr
    password: str = Field(min_length=10,max_length=128)
    workspace_name: str = Field(default="My Workspace",max_length=160)
class LoginIn(BaseModel):
    email: EmailStr
    password: str
class LeadIn(BaseModel):
    name: str
    company: str=""
    email: str=""
    source: str="manual"
    status: str="new"
    score: int=0
    notes: str=""
class ResearchIn(BaseModel):
    title: str
    company: str=""
    url: str=""
    summary: str=""
    score: int=0
    status: str="saved"
class ContentIn(BaseModel):
    title: str
    channel: str="blog"
    body: str=""
    status: str="draft"
class CampaignIn(BaseModel):
    name: str
    channel: str="email"
    audience: int=0
class ApprovalIn(BaseModel):
    action_type: str
    title: str
    payload: dict = {}
class DecisionIn(BaseModel):
    decision: str
class BudgetIn(BaseModel):
    ai_budget_usd: float = Field(ge=0,le=100000)

class MarketProfileIn(BaseModel):
    country_code: str = Field(default="US", pattern="^(US|CA|NG|GB|AU|OTHER)$")
    currency_code: str = Field(default="USD", pattern="^(USD|CAD|NGN|GBP|AUD|EUR)$")
    timezone: str = Field(default="America/New_York", min_length=3, max_length=80)
    state_or_province: str = Field(default="", max_length=100)
    business_type: str = Field(default="small_business", pattern="^(small_business|agency|enterprise)$")
    workspace_type: str = Field(default="business", pattern="^(business|agency)$")
    industry: str = Field(default="home_services", max_length=100)
    website: str = Field(default="", max_length=500)

@app.get("/market/config")
def market_config():
    """Public market metadata. Pricing and payment availability are configured separately."""
    return {
        "brand": "AdNova Global",
        "launch_market": "US",
        "supported_markets": [
            {"country_code": "US", "name": "United States", "currency": "USD", "launch_status": "initial_market", "default_timezone": "America/New_York"},
            {"country_code": "CA", "name": "Canada", "currency": "CAD", "launch_status": "expansion_market", "default_timezone": "America/Toronto"},
            {"country_code": "NG", "name": "Nigeria", "currency": "NGN", "launch_status": "configuration_available", "default_timezone": "Africa/Lagos"},
        ],
        "workspace_types": ["business", "agency"],
        "industries": ["home_services", "ecommerce", "real_estate", "professional_services", "marketing_agency", "other"],
        "notice": "Market configuration does not imply that billing, tax registration, advertising-provider access or legal compliance is enabled in every country."
    }

@app.get("/workspace/market-profile")
def get_market_profile(u:User=Depends(current_user), s:Session=Depends(db)):
    profile=s.scalar(select(WorkspaceMarketProfile).where(WorkspaceMarketProfile.workspace_id==u.workspace_id))
    if not profile:
        profile=WorkspaceMarketProfile(workspace_id=u.workspace_id)
        s.add(profile); s.commit(); s.refresh(profile)
    return {"country_code":profile.country_code,"currency_code":profile.currency_code,"timezone":profile.timezone,"state_or_province":profile.state_or_province,"business_type":profile.business_type,"workspace_type":profile.workspace_type,"industry":profile.industry,"website":profile.website,"updated_at":profile.updated_at.isoformat()}

@app.put("/workspace/market-profile")
def update_market_profile(data:MarketProfileIn,u:User=Depends(current_user),s:Session=Depends(db)):
    # Enforce a safe country/currency pairing for the currently enabled launch markets.
    expected={"US":"USD","CA":"CAD","NG":"NGN"}
    if data.country_code in expected and data.currency_code != expected[data.country_code]:
        raise HTTPException(422, f"{data.country_code} workspaces must use {expected[data.country_code]} in this release")
    profile=s.scalar(select(WorkspaceMarketProfile).where(WorkspaceMarketProfile.workspace_id==u.workspace_id))
    if not profile:
        profile=WorkspaceMarketProfile(workspace_id=u.workspace_id); s.add(profile)
    for key,value in data.model_dump().items(): setattr(profile,key,value)
    profile.updated_at=datetime.now(timezone.utc)
    audit(s,u,"workspace.market_profile.updated",f"{profile.country_code}/{profile.currency_code}/{profile.workspace_type}")
    s.commit(); s.refresh(profile)
    return {"status":"saved","country_code":profile.country_code,"currency_code":profile.currency_code,"workspace_type":profile.workspace_type,"industry":profile.industry}

@app.get("/health")
def health():
    return {"status":"ok","service":"adnova-api","version":"1.1.0"}

@app.post("/auth/register")
def register(data:RegisterIn,s:Session=Depends(db)):
    email=data.email.lower()
    if s.scalar(select(User).where(User.email==email)): raise HTTPException(409,"Email already registered")
    w=Workspace(name=data.workspace_name)
    s.add(w); s.flush()
    u=User(workspace_id=w.id,email=email,full_name=data.full_name,password_hash=pwd.hash(data.password),role="owner")
    s.add(u); s.flush()
    s.add(Subscription(workspace_id=w.id))
    audit(s,u,"workspace.created",w.name); s.commit()
    return {"access_token":token_for(u),"token_type":"bearer","user":{"id":u.id,"name":u.full_name,"email":u.email,"role":u.role},"workspace":{"id":w.id,"name":w.name,"plan":w.plan,"trial_ends_at":w.trial_ends_at.isoformat()}}
@app.post("/auth/login")
def login(data:LoginIn,s:Session=Depends(db)):
    u=s.scalar(select(User).where(User.email==data.email.lower()))
    if not u or not pwd.verify(data.password,u.password_hash): raise HTTPException(401,"Incorrect email or password")
    w=s.get(Workspace,u.workspace_id)
    return {"access_token":token_for(u),"token_type":"bearer","user":{"id":u.id,"name":u.full_name,"email":u.email,"role":u.role},"workspace":{"id":w.id,"name":w.name,"plan":w.plan,"trial_ends_at":w.trial_ends_at.isoformat()}}
@app.get("/auth/me")
def me(u:User=Depends(current_user),s:Session=Depends(db)):
    w=s.get(Workspace,u.workspace_id)
    return {"id":u.id,"name":u.full_name,"email":u.email,"role":u.role,"workspace":{"id":w.id,"name":w.name,"plan":w.plan,"trial_ends_at":w.trial_ends_at.isoformat(),"ai_budget_usd":w.ai_budget_usd,"ai_spend_usd":w.ai_spend_usd}}

@app.get("/dashboard")
def dashboard(u:User=Depends(current_user),s:Session=Depends(db)):
    wid=u.workspace_id
    counts={k:s.scalar(select(func.count()).select_from(m).where(m.workspace_id==wid)) or 0 for k,m in [("leads",Lead),("research",ResearchItem),("content",ContentItem),("campaigns",Campaign)]}
    pending=s.scalar(select(func.count()).select_from(Approval).where(Approval.workspace_id==wid,Approval.status=="pending")) or 0
    won=s.scalar(select(func.count()).select_from(Lead).where(Lead.workspace_id==wid,Lead.status=="won")) or 0
    recent=s.scalars(select(Activity).where(Activity.workspace_id==wid).order_by(Activity.created_at.desc()).limit(8)).all()
    return {"metrics":{"leads":counts["leads"],"research_items":counts["research"],"content_items":counts["content"],"campaigns":counts["campaigns"],"pending_approvals":pending,"won_leads":won},"pipeline":[{"stage":x,"count":s.scalar(select(func.count()).select_from(Lead).where(Lead.workspace_id==wid,Lead.status==x)) or 0} for x in ["new","qualified","contacted","proposal","won","lost"]],"recent_activity":[{"id":a.id,"kind":a.kind,"description":a.description,"created_at":a.created_at.isoformat()} for a in recent],"revenue":{"recorded_usd":0,"note":"Revenue is zero until verified payment events are connected."}}

def list_rows(s, model, wid):
    return s.scalars(select(model).where(model.workspace_id==wid).order_by(model.created_at.desc()).limit(200)).all()
@app.get("/leads")
def leads(u:User=Depends(current_user),s:Session=Depends(db)):
    return [{"id":x.id,"name":x.name,"company":x.company,"email":x.email,"source":x.source,"status":x.status,"score":x.score,"notes":x.notes,"created_at":x.created_at.isoformat()} for x in list_rows(s,Lead,u.workspace_id)]
@app.post("/leads")
def add_lead(d:LeadIn,u:User=Depends(current_user),s:Session=Depends(db)):
    x=Lead(workspace_id=u.workspace_id,**d.model_dump()); s.add(x); s.flush()
    s.add(Activity(workspace_id=u.workspace_id,lead_id=x.id,kind="lead.created",description=f"Lead added: {x.name}")); audit(s,u,"lead.created",x.name); s.commit()
    return {"id":x.id,"name":x.name,"status":x.status}
@app.patch("/leads/{item_id}")
def update_lead(item_id:str,d:LeadIn,u:User=Depends(current_user),s:Session=Depends(db)):
    x=s.scalar(select(Lead).where(Lead.id==item_id,Lead.workspace_id==u.workspace_id))
    if not x: raise HTTPException(404,"Lead not found")
    for k,v in d.model_dump().items(): setattr(x,k,v)
    s.add(Activity(workspace_id=u.workspace_id,lead_id=x.id,kind="lead.updated",description=f"Lead updated: {x.name}")); s.commit()
    return {"id":x.id,"status":x.status}

@app.get("/research")
def research(u:User=Depends(current_user),s:Session=Depends(db)):
    return [{"id":x.id,"title":x.title,"company":x.company,"url":x.url,"summary":x.summary,"score":x.score,"status":x.status,"created_at":x.created_at.isoformat()} for x in list_rows(s,ResearchItem,u.workspace_id)]
@app.post("/research")
def add_research(d:ResearchIn,u:User=Depends(current_user),s:Session=Depends(db)):
    x=ResearchItem(workspace_id=u.workspace_id,**d.model_dump()); s.add(x); audit(s,u,"research.saved",x.title); s.commit(); return {"id":x.id,"title":x.title}

@app.get("/content")
def content(u:User=Depends(current_user),s:Session=Depends(db)):
    return [{"id":x.id,"title":x.title,"channel":x.channel,"body":x.body,"status":x.status,"created_at":x.created_at.isoformat()} for x in list_rows(s,ContentItem,u.workspace_id)]
@app.post("/content")
def add_content(d:ContentIn,u:User=Depends(current_user),s:Session=Depends(db)):
    x=ContentItem(workspace_id=u.workspace_id,**d.model_dump()); s.add(x); audit(s,u,"content.created",x.title); s.commit(); return {"id":x.id,"title":x.title}
@app.post("/content/{item_id}/publish")
def publish_content(item_id:str,u:User=Depends(current_user),s:Session=Depends(db)):
    x=s.scalar(select(ContentItem).where(ContentItem.id==item_id,ContentItem.workspace_id==u.workspace_id))
    if not x: raise HTTPException(404,"Content not found")
    raise HTTPException(501,"Publishing adapter is not configured. Connect and verify a publishing provider before enabling live publication.")

@app.get("/campaigns")
def campaigns(u:User=Depends(current_user),s:Session=Depends(db)):
    return [{"id":x.id,"name":x.name,"channel":x.channel,"status":x.status,"audience":x.audience,"created_at":x.created_at.isoformat()} for x in list_rows(s,Campaign,u.workspace_id)]
@app.post("/campaigns")
def add_campaign(d:CampaignIn,u:User=Depends(current_user),s:Session=Depends(db)):
    x=Campaign(workspace_id=u.workspace_id,**d.model_dump()); s.add(x); audit(s,u,"campaign.created",x.name); s.commit(); return {"id":x.id,"name":x.name,"status":x.status}
@app.post("/campaigns/{campaign_id}/request-send")
def request_send(campaign_id:str,u:User=Depends(current_user),s:Session=Depends(db)):
    x=s.scalar(select(Campaign).where(Campaign.id==campaign_id,Campaign.workspace_id==u.workspace_id))
    if not x: raise HTTPException(404,"Campaign not found")
    a=Approval(workspace_id=u.workspace_id,action_type="campaign.first_contact",title=f"Approve campaign: {x.name}",payload=json.dumps({"campaign_id":x.id,"channel":x.channel}),requested_by=u.id)
    s.add(a); audit(s,u,"approval.requested",x.name); s.commit()
    return {"approval_id":a.id,"status":"pending","message":"Approval required before first-contact outreach."}

@app.get("/approvals")
def approvals(u:User=Depends(current_user),s:Session=Depends(db)):
    return [{"id":x.id,"action_type":x.action_type,"title":x.title,"payload":json.loads(x.payload or "{}"),"status":x.status,"created_at":x.created_at.isoformat()} for x in list_rows(s,Approval,u.workspace_id)]
@app.post("/approvals/{approval_id}/decision")
def decide(approval_id:str,d:DecisionIn,u:User=Depends(current_user),s:Session=Depends(db)):
    if d.decision not in ("approved","rejected"): raise HTTPException(400,"Decision must be approved or rejected")
    a=s.scalar(select(Approval).where(Approval.id==approval_id,Approval.workspace_id==u.workspace_id))
    if not a: raise HTTPException(404,"Approval not found")
    a.status=d.decision; a.decided_by=u.id; a.decided_at=datetime.now(timezone.utc); audit(s,u,f"approval.{d.decision}",a.title); s.commit()
    return {"id":a.id,"status":a.status,"note":"Approval is recorded. External execution remains provider- and policy-gated."}

@app.get("/billing")
def billing(u:User=Depends(current_user),s:Session=Depends(db)):
    w=s.get(Workspace,u.workspace_id); sub=s.scalar(select(Subscription).where(Subscription.workspace_id==u.workspace_id))
    return {"plan":w.plan,"trial_ends_at":w.trial_ends_at.isoformat(),"subscription":{"status":sub.status if sub else "trialing","plan":sub.plan if sub else "starter","monthly_amount_usd":sub.monthly_amount_usd if sub else 0},"payment_provider_configured":bool(os.getenv("STRIPE_SECRET_KEY"))}
@app.post("/billing/checkout")
def checkout(u:User=Depends(current_user)):
    if not os.getenv("STRIPE_SECRET_KEY"): raise HTTPException(503,"Payment provider is not configured. Add and test provider credentials before accepting payments.")
    raise HTTPException(501,"Checkout adapter and signed webhook verification must be configured before live billing.")

@app.get("/analytics")
def analytics(u:User=Depends(current_user),s:Session=Depends(db)):
    wid=u.workspace_id
    return {"funnel":[{"stage":x,"count":s.scalar(select(func.count()).select_from(Lead).where(Lead.workspace_id==wid,Lead.status==x)) or 0} for x in ["new","qualified","contacted","proposal","won","lost"]],"content_by_status":[{"status":x,"count":s.scalar(select(func.count()).select_from(ContentItem).where(ContentItem.workspace_id==wid,ContentItem.status==x)) or 0} for x in ["draft","review","scheduled","published"]],"revenue_usd":0,"revenue_note":"Only verified provider payment events should populate revenue."}
@app.get("/settings")
def settings(u:User=Depends(current_user),s:Session=Depends(db)):
    w=s.get(Workspace,u.workspace_id)
    return {"workspace_name":w.name,"ai_budget_usd":w.ai_budget_usd,"ai_spend_usd":w.ai_spend_usd,"role":u.role}
@app.patch("/settings/ai-budget")
def set_budget(d:BudgetIn,u:User=Depends(current_user),s:Session=Depends(db)):
    if u.role!="owner": raise HTTPException(403,"Owner role required")
    w=s.get(Workspace,u.workspace_id); w.ai_budget_usd=d.ai_budget_usd; s.commit(); return {"ai_budget_usd":w.ai_budget_usd}

@app.post("/ai/estimate")
def ai_estimate(prompt:str=Header(default="",alias="X-AI-Prompt"),u:User=Depends(current_user),s:Session=Depends(db)):
    w=s.get(Workspace,u.workspace_id)
    estimate=max(0.001,len(prompt)/1000*0.02)
    return {"estimated_cost_usd":round(estimate,4),"budget_usd":w.ai_budget_usd,"spent_usd":w.ai_spend_usd,"allowed":w.ai_spend_usd+estimate<=w.ai_budget_usd,"provider_configured":bool(os.getenv("AI_API_KEY")),"message":"Cost estimate only; no model call is made by this endpoint."}

@app.get("/audit")
def audit_log(u:User=Depends(current_user),s:Session=Depends(db)):
    rows=s.scalars(select(AuditEvent).where(AuditEvent.workspace_id==u.workspace_id).order_by(AuditEvent.created_at.desc()).limit(100)).all()
    return [{"id":x.id,"event":x.event,"details":x.details,"created_at":x.created_at.isoformat()} for x in rows]
