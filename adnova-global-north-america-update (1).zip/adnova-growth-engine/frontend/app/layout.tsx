import "./globals.css";
export const metadata={title:"AdNova Global | AI Growth Platform",description:"AI-powered growth operations for businesses and agencies worldwide"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
