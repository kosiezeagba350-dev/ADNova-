import type { Config } from "tailwindcss";
const config: Config = { content: ["./app/**/*.{js,ts,jsx,tsx}"], theme: { extend: { colors: { violet: { 50:"#f5f3ff",100:"#ede9fe",500:"#8b5cf6",600:"#7c3aed",700:"#6d28d9" } }, boxShadow: { soft:"0 8px 30px rgba(32, 24, 66, .06)" } } }, plugins: [] };
export default config;
