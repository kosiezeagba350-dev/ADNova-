# AdNova Global — North American Architecture

## Confirmed product decisions
- Brand identity: global technology company; do not imply US incorporation or US headquarters unless those facts become true.
- Market order: United States first, Canada second.
- Distribution: direct SMB sales plus agency partnerships.
- Initial vertical: US home-services SMBs, with marketing agencies as a parallel channel.
- Product architecture: one global codebase with country-aware configuration, not separate country forks.

## Target architecture

```text
Next.js web application
  ├── Global marketing site and US landing pages
  ├── Business workspace
  ├── Agency portal (future multi-client capabilities)
  ├── Billing and usage UI
  └── Trust Centre
          |
FastAPI application
  ├── Identity, workspace and RBAC
  ├── Market configuration and localisation
  ├── Business onboarding and industry templates
  ├── CRM, campaigns, approvals and analytics
  ├── AI orchestration and usage metering
  ├── Billing and signed webhook processing
  ├── Integrations: Meta, Google, analytics, email
  └── Governance: consent, audit, budget controls
          |
Neon PostgreSQL | Redis/job queue | object storage | provider APIs
```

## Data model additions in this release
`workspace_market_profiles` is a one-to-one extension of `workspaces`, keyed by `workspace_id`. It stores `country_code`, `currency_code`, `timezone`, `state_or_province`, `business_type`, `workspace_type`, `industry`, `website` and `updated_at`. A separate table avoids altering the existing `workspaces` table in place; SQLAlchemy `create_all` creates the new table on startup. Production should still move to explicit Alembic migrations before broader schema evolution.

## API additions in this release
- `GET /market/config` — public market metadata; explicitly does not promise billing or legal availability.
- `GET /workspace/market-profile` — authenticated workspace profile.
- `PUT /workspace/market-profile` — authenticated profile update with country/currency pairing validation for US, Canada and Nigeria.

## Agency distribution model (next engineering stage)
Implement a separate `agency_client_relationships` table linking an agency workspace to a client workspace. Do not merge client data into the agency tenant. Add invitation tokens with expiry, explicit client acceptance, scoped roles, per-client OAuth connections, client-level budget caps and audit events. Agency users must only access client workspaces through an active relationship and an explicit permission check on every request. Agency billing should be distinct from the client's media spend.

## Trust and security work (launch blockers)
1. Replace development JWT defaults; enforce strong secret management and token rotation.
2. Add rate limiting, login abuse protection, session revocation and MFA option.
3. Encrypt third-party OAuth credentials at rest; restrict scopes and support disconnect/revoke.
4. Add tenant-isolation tests for every workspace-scoped endpoint.
5. Add signed, replay-protected payment and provider webhooks with idempotency.
6. Add privacy request workflows: access, export, deletion and retention schedule.
7. Add consent and suppression management before any commercial email/SMS automation.
8. Publish truthful security, privacy, subprocessor and incident-response documentation. Do not claim SOC 2 or ISO certification until independently obtained.
9. Commission an independent penetration test before enterprise launch.

## Market rollout sequence
### Stage A — US pilot
- US landing page and English-US copy.
- USD display and US time-zone support.
- Home-services onboarding and templates.
- 10–20 pilot businesses; manual customer success; customer-approved campaigns.
- Confirm Stripe or alternative provider eligibility, merchant entity, tax obligations and payout path before charging.

### Stage B — Agency distribution
- Agency client relationship model and delegated roles.
- Partner referral attribution and commission ledger.
- Multi-client dashboard, white-label reporting and consolidated billing options.
- Pilot with 3–5 agencies; measure activated clients and retention.

### Stage C — Canada
- CAD pricing and billing after payment-provider validation.
- Canadian province/time-zone and privacy/consent settings.
- CASL workflows and applicable privacy controls reviewed by qualified counsel.
- Canadian pilot customers and local case studies.

### Stage D — Scale
- Shopify/CRM/analytics integrations.
- Free audit and calculator tools for SEO acquisition.
- Partner marketplace, referral engine and measured paid acquisition.
- Observability, queue scaling, backups, disaster recovery and security assurance.

## Launch gates (must be true before paid public launch)
- Live payment checkout and signed webhook verified end-to-end.
- Real provider OAuth/API access approved and tested; no mock ad launch presented as live.
- Spend caps, emergency pause and explicit approval before material financial actions.
- Verified attribution separated from estimates and platform-reported conversions.
- Privacy/terms, data deletion and support escalation operational.
- Tenant isolation and security tests passing.
- No invented customer logos, testimonials, performance metrics or US corporate footprint.
