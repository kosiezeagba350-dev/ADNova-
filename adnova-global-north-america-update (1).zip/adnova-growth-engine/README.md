# AdNova Global — Growth Engine

Integrated monorepo for AdNova Global: a multi-tenant growth operations SaaS with a Next.js dashboard and FastAPI API. The commercial rollout is US-first, followed by Canada, while preserving a global product identity.

## Included modules
- Identity, JWT sessions, tenant isolation and role-aware workspace foundation
- Founder dashboard and KPI summaries
- CRM leads, pipeline stages and activity timeline
- Research workspace, discovery records and lead scoring
- SEO/content planning and publishing queue (publishing requires configured provider credentials)
- Outreach campaigns, contacts and approval-gated first-contact actions
- Approval inbox for external actions
- 14-day trials, subscription records and billing-provider integration seam
- Revenue, funnel and retention analytics
- AI provider abstraction with per-tenant monthly budget guardrails
- Audit events, health endpoint and deployment configuration
- Initial market configuration API for US, Canada and Nigeria
- Workspace market profile (country, currency, time zone, business/agency type, industry and website)
- US-first market metadata endpoint and country/currency validation

## Stack
- Frontend: Next.js App Router, TypeScript, Tailwind CSS, Recharts, Lucide
- Backend: FastAPI, SQLAlchemy 2, Alembic, PostgreSQL/Neon, JWT
- Hosting: Render (blueprint included); database: Neon PostgreSQL

## Quick start

### 1. Backend
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --port 8000
```
The API docs are at `http://localhost:8000/docs`. SQLite is used by default for local development. Set `DATABASE_URL` to your Neon PostgreSQL connection string in production.

### 2. Frontend
```bash
cd frontend
npm install
cp .env.example .env.local
npm run dev
```
Open `http://localhost:3000`.

## First user
Register through `/register`. The first registered account creates its own workspace. Additional accounts can be invited later through the workspace administration module (invitation delivery is intentionally not enabled until an email provider is configured).

## North American rollout architecture

AdNova uses one global codebase with market-aware workspace configuration. The US is the first commercial launch market; Canada is the next planned market. A workspace records its country, currency, time zone, state/province, business type, workspace type, industry and website. The public `GET /market/config` endpoint describes the currently configured markets. Authenticated `GET/PUT /workspace/market-profile` reads and updates the active workspace profile.

The current release only stores market preferences; it does not establish tax registrations, payment-provider eligibility, legal compliance, ad-platform approval or localized tax calculations. USD and CAD checkout must remain disabled until a payment provider and country-specific merchant setup have been verified. The `agency` workspace type is an initial classification only: cross-workspace client invitations, delegated access and agency billing are future implementation work.

See `docs/NORTH_AMERICA_ARCHITECTURE.md` for the phased architecture and launch gates.

## Production environment
Backend:
- `DATABASE_URL` — Neon PostgreSQL URL; use `postgresql+psycopg://...`
- `JWT_SECRET` — long random secret (required in production)
- `FRONTEND_ORIGIN` — deployed Next.js origin
- `AI_PROVIDER` / `AI_API_KEY` — optional model provider configuration
- `AI_MONTHLY_BUDGET_USD` — default tenant AI budget
- `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET` — optional billing integration
- `RESEND_API_KEY` — optional transactional email provider
- `APP_ENV=production`

Frontend:
- `NEXT_PUBLIC_API_URL` — deployed FastAPI base URL, e.g. `https://your-api.onrender.com`

## Render deployment
A `render.yaml` blueprint is included. Create a Neon database first, then set the backend environment variables in Render. Deploy the backend and frontend as separate Render services. Configure `NEXT_PUBLIC_API_URL` on the frontend to the backend URL and `FRONTEND_ORIGIN` on the backend to the frontend URL.

## Important operational safeguards
- No fake ad impressions, clicks, traffic or revenue are generated. Dashboard demo values are labelled as illustrative until real events are recorded.
- First-contact outreach and financial commitments are approval-gated. The app stores proposed actions; it does not silently send emails or spend money.
- Publishing and email delivery require explicit provider credentials and adapter configuration.
- Billing records support trials and subscription states. Live payment collection must be connected to a payment provider and tested with its webhook signing secret before being enabled.
- AI usage is estimated and checked against a tenant budget before a provider call. Provider usage is not guaranteed to match estimates exactly.
- Configure HTTPS, backups, database pooling, monitoring, rate limiting and secrets before public launch.

## Tests
```bash
cd backend
pytest
```

This package is a deployable foundation with working core flows and integration seams. External services (email, payment, social publishing and model providers) remain disabled until their credentials and production adapters are configured.
